package com.sebaainf.fichfamil.citoyen;

import com.sebaainf.fichfamil.common.Deces;

import java.sql.Date;

/**
 * Created by ${sebaainf.com} on 15/03/2015.
 */
public interface IPerson {

    Date getDate_naiss();

    void setDate_naiss(Date newDate_naiss);


    public Deces getDeces();

    public void setDeces(Deces deces);
}
