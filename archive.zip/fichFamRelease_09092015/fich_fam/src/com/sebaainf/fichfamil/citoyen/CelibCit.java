package com.sebaainf.fichfamil.citoyen;

/**
 * Created by admin on 10/01/2015.
 */
public class CelibCit extends Citoyen {

    public CelibCit() {

        this.setSit_famil("c");
    }

}
