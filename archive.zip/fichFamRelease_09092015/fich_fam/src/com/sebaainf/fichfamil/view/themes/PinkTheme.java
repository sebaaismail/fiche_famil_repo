package com.sebaainf.fichfamil.view.themes;

import com.jgoodies.looks.Fonts;

import java.awt.*;

/**
 * Created by ${sebaainf.com} on 24/02/2015.
 */
public class PinkTheme extends MyTheme {

    public PinkTheme() {

        this.buttonBarColor = Color.decode("#5F5B85");
        this.buttonsBackgroundColor = Color.decode("#9EB4D9");
        this.font = Fonts.WINDOWS_VISTA_96DPI_LARGE;
    }

}
