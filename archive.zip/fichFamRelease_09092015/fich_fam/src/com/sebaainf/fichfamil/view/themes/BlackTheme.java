package com.sebaainf.fichfamil.view.themes;

import com.jgoodies.looks.Fonts;

import java.awt.*;

/**
 * Created by ${sebaainf.com} on 24/02/2015.
 */
public class BlackTheme extends MyTheme {

    public BlackTheme() {

        this.buttonBarColor = Color.decode("#4E594E");
        this.buttonsBackgroundColor = Color.decode("#E8F0FA");
        this.font = Fonts.WINDOWS_VISTA_96DPI_LARGE;
    }

}
