package com.sebaainf.fichfamil.view.themes;

import com.jgoodies.looks.Fonts;

import java.awt.*;

/**
 * Created by ${sebaainf.com} on 24/02/2015.
 */
public class GreyTheme extends MyTheme {

    public GreyTheme() {

        this.buttonBarColor = Color.decode("#AAB0B3");
        this.buttonsBackgroundColor = Color.decode("#E3E3E3");
        this.font = Fonts.WINDOWS_VISTA_96DPI_LARGE;
    }

}
