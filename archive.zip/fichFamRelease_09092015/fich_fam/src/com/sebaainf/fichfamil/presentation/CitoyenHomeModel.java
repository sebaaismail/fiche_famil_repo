package com.sebaainf.fichfamil.presentation;

/**
 * Created by ${sebaainf.com} on 30/03/2015.
 * https://bitbucket.org/sebaa_ismail
 * https://github.com/sebaaismail
 */
public class CitoyenHomeModel {

    // TODO

}
